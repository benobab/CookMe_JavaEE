# CookMe_JavaEE
Projet de site web - Java EE

Concepts mis en oeuvre :
+ servlet
+ jsp
+ java bean
+ jsf
+ jdbc

L'architecture respectera les principes MVC.
